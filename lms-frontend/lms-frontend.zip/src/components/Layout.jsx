import { useState, useEffect } from 'react';
import { Link, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../styles/layout.css';

const Layout = () => {
  const { user, logout, currentSection, switchSection, canAccessSection, selectedSchool, selectedCenter } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Super admin sidebar visibility controls
  const [sidebarConfig, setSidebarConfig] = useState(() => {
    const saved = localStorage.getItem('sidebarConfig');
    return saved ? JSON.parse(saved) : {
      showSchoolSection: true,
      showCenterSection: true,
      showAdminSection: true,
      hiddenItems: []
    };
  });

  const [showConfigPanel, setShowConfigPanel] = useState(false);

  // Save config to localStorage
  useEffect(() => {
    localStorage.setItem('sidebarConfig', JSON.stringify(sidebarConfig));
  }, [sidebarConfig]);

  // Check if user is super admin (developer)
  const isSuperAdmin = user?.role_name === 'developer';

  // Determine if user can switch between sections
  const canSwitchSections = canAccessSection('school') && canAccessSection('center');

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleSectionSwitch = (section) => {
    switchSection(section);
    navigate(section === 'school' ? '/school/dashboard' : '/center/dashboard');
  };

  const toggleSidebarItem = (itemPath) => {
    setSidebarConfig(prev => ({
      ...prev,
      hiddenItems: prev.hiddenItems.includes(itemPath)
        ? prev.hiddenItems.filter(p => p !== itemPath)
        : [...prev.hiddenItems, itemPath]
    }));
  };

  const schoolMenuItems = [
    { path: '/school/dashboard', label: 'Dashboard', roles: ['developer', 'owner', 'principal', 'school_teacher', 'trainer_head', 'trainer'] },
    { path: '/school/classes', label: 'Classes', roles: ['developer', 'owner', 'school_teacher'] },
    { path: '/school/students', label: 'Students', roles: ['developer', 'owner', 'school_teacher', 'principal', 'trainer', 'trainer_head'] },
    { path: '/school/timetable', label: 'Timetable', roles: ['developer', 'owner', 'school_teacher', 'trainer', 'trainer_head'] },
    { path: '/school/attendance', label: 'Attendance', roles: ['developer', 'owner', 'trainer', 'trainer_head'] },
  ];

  const centerMenuItems = [
    { path: '/center/dashboard', label: 'Dashboard', roles: ['developer', 'owner', 'trainer_head', 'trainer'] },
    { path: '/center/students', label: 'Students', roles: ['developer', 'owner', 'trainer_head', 'trainer'] },
    { path: '/center/attendance', label: 'Attendance', roles: ['developer', 'owner', 'trainer_head', 'trainer'] },
    { path: '/center/progress', label: 'Progress', roles: ['developer', 'owner', 'trainer_head', 'trainer'] },
    { path: '/center/curriculum', label: 'Curriculum', roles: ['developer', 'owner', 'trainer_head'] },
  ];

  const adminMenuItems = [
    { path: '/admin/users', label: 'Users', roles: ['developer', 'owner'] },
    { path: '/admin/schools', label: 'Schools', roles: ['developer', 'owner'] },
    { path: '/admin/centers', label: 'Centers', roles: ['developer', 'owner'] },
    { path: '/admin/trainer-assignments', label: 'Trainer Assignments', roles: ['developer', 'owner', 'trainer_head'] },
    { path: '/admin/teacher-assignments', label: 'Teacher Assignments', roles: ['developer', 'owner'] },
  ];

  const menuItems = currentSection === 'school' ? schoolMenuItems : centerMenuItems;
  
  // Filter by role and visibility config
  const filteredMenu = menuItems
    .filter(item => item.roles.includes(user?.role_name))
    .filter(item => !sidebarConfig.hiddenItems.includes(item.path));
  
  const filteredAdmin = adminMenuItems
    .filter(item => item.roles.includes(user?.role_name))
    .filter(item => !sidebarConfig.hiddenItems.includes(item.path));

  // Check if current path is active
  const isActive = (path) => location.pathname === path;

  // Should show sections based on config
  const showSchool = sidebarConfig.showSchoolSection && canAccessSection('school');
  const showCenter = sidebarConfig.showCenterSection && canAccessSection('center');
  const showAdmin = sidebarConfig.showAdminSection && filteredAdmin.length > 0;

  return (
    <div className="app-layout">
      <header className="header">
        <div className="header-left">
          <h1 className="logo">LMS</h1>
          {(showSchool && showCenter) && (
            <div className="section-switcher">
              <button 
                className={`section-btn ${currentSection === 'school' ? 'active' : ''}`}
                onClick={() => handleSectionSwitch('school')}
              >
                School
              </button>
              <button 
                className={`section-btn ${currentSection === 'center' ? 'active' : ''}`}
                onClick={() => handleSectionSwitch('center')}
              >
                Center
              </button>
            </div>
          )}
        </div>
        <div className="header-right">
          <span className="current-entity">
            {currentSection === 'school' ? selectedSchool?.name : selectedCenter?.name}
          </span>
          <span className="user-info">{user?.first_name} ({user?.role_name})</span>
          {isSuperAdmin && (
            <button 
              onClick={() => setShowConfigPanel(!showConfigPanel)} 
              className="config-btn"
              title="Configure Sidebar"
            >
              ⚙️
            </button>
          )}
          <button onClick={handleLogout} className="logout-btn">Logout</button>
        </div>
      </header>

      {/* Super Admin Config Panel */}
      {isSuperAdmin && showConfigPanel && (
        <div className="config-panel">
          <div className="config-panel-header">
            <h3>Sidebar Configuration</h3>
            <button onClick={() => setShowConfigPanel(false)} className="close-btn">×</button>
          </div>
          
          <div className="config-section">
            <h4>Section Visibility</h4>
            <label className="config-toggle">
              <input 
                type="checkbox" 
                checked={sidebarConfig.showSchoolSection}
                onChange={(e) => setSidebarConfig(prev => ({ ...prev, showSchoolSection: e.target.checked }))}
              />
              <span>Show School Section</span>
            </label>
            <label className="config-toggle">
              <input 
                type="checkbox" 
                checked={sidebarConfig.showCenterSection}
                onChange={(e) => setSidebarConfig(prev => ({ ...prev, showCenterSection: e.target.checked }))}
              />
              <span>Show Center Section</span>
            </label>
            <label className="config-toggle">
              <input 
                type="checkbox" 
                checked={sidebarConfig.showAdminSection}
                onChange={(e) => setSidebarConfig(prev => ({ ...prev, showAdminSection: e.target.checked }))}
              />
              <span>Show Admin Section</span>
            </label>
          </div>

          <div className="config-section">
            <h4>School Menu Items</h4>
            {schoolMenuItems.map(item => (
              <label key={item.path} className="config-toggle">
                <input 
                  type="checkbox" 
                  checked={!sidebarConfig.hiddenItems.includes(item.path)}
                  onChange={() => toggleSidebarItem(item.path)}
                />
                <span>{item.label}</span>
              </label>
            ))}
          </div>

          <div className="config-section">
            <h4>Center Menu Items</h4>
            {centerMenuItems.map(item => (
              <label key={item.path} className="config-toggle">
                <input 
                  type="checkbox" 
                  checked={!sidebarConfig.hiddenItems.includes(item.path)}
                  onChange={() => toggleSidebarItem(item.path)}
                />
                <span>{item.label}</span>
              </label>
            ))}
          </div>

          <div className="config-section">
            <h4>Admin Menu Items</h4>
            {adminMenuItems.map(item => (
              <label key={item.path} className="config-toggle">
                <input 
                  type="checkbox" 
                  checked={!sidebarConfig.hiddenItems.includes(item.path)}
                  onChange={() => toggleSidebarItem(item.path)}
                />
                <span>{item.label}</span>
              </label>
            ))}
          </div>

          <button 
            className="btn-reset"
            onClick={() => setSidebarConfig({
              showSchoolSection: true,
              showCenterSection: true,
              showAdminSection: true,
              hiddenItems: []
            })}
          >
            Reset to Default
          </button>
        </div>
      )}

      <div className="main-container">
        <nav className="sidebar">
          <ul className="nav-menu">
            {filteredMenu.map(item => (
              <li key={item.path}>
                <Link to={item.path} className={isActive(item.path) ? 'active' : ''}>{item.label}</Link>
              </li>
            ))}
            {showAdmin && (
              <>
                <li className="nav-divider">Admin</li>
                {filteredAdmin.map(item => (
                  <li key={item.path}>
                    <Link to={item.path} className={isActive(item.path) ? 'active' : ''}>{item.label}</Link>
                  </li>
                ))}
              </>
            )}
          </ul>
        </nav>

        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
